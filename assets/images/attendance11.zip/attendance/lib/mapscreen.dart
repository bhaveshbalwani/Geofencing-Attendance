import 'dart:async';
import 'dart:collection';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({Key? key}) : super(key: key);

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {

  @override
  void initState() {
    super.initState();
    _polygon.add(
        Polygon(polygonId: PolygonId('1'), points: points,
          fillColor: Colors.red.withOpacity(0),
          geodesic: true,
          strokeWidth: 2,
          strokeColor: Colors.blue,
        )
    );
  }

  final Completer<GoogleMapController> _controller = Completer();

  CameraPosition _GHRCE = CameraPosition(
    target: LatLng(21.105651, 79.002865),
    zoom: 17,
  );

  final List<Marker> _marker = <Marker>[
    Marker(
      markerId: MarkerId('1'),
      position: LatLng(21.10524776039567, 79.00349029772943),
      infoWindow: InfoWindow(
        title: 'GHRCE',
      ),
    ),
  ];

  final Set<Polygon> _polygon = HashSet<Polygon>();

  List<LatLng> points = [
    const LatLng(21.105651, 79.002865),
    const LatLng(21.105822, 79.003675),
    const LatLng(21.104259, 79.004250),
    const LatLng(21.104054, 79.003425),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GoogleMap(
        markers: Set<Marker>.of(_marker),
        mapType: MapType.normal,
        initialCameraPosition: _GHRCE,
        myLocationButtonEnabled: true,
        myLocationEnabled: true,
        polygons: _polygon,
        onMapCreated: (GoogleMapController controller){
          _controller.complete(controller);
        },
      ),
    );
  }
}
