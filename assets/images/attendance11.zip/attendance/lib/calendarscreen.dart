import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flip_card/flip_card.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:progresso/progresso.dart';
import 'model/user.dart';
import 'package:month_picker_dialog/month_picker_dialog.dart';

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({Key? key}) : super(key: key);

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {

  double screenHeight = 0;
  double screenWidth = 0;

  Color primary = const Color(0xffeef444c);

  String _month = DateFormat('MMMM').format(DateTime.now());


  @override
  Widget build(BuildContext context) {

    screenHeight = MediaQuery.of(context).size.height;
    screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              alignment: Alignment.center,
              margin: const EdgeInsets.only(top: 32,bottom: 16),
              child: Text(
                "Attendance" ,
                style: TextStyle(
                  fontFamily: "BebasNeue-Bold",
                  fontSize: screenWidth / 18,
                ),
              ),
            ),
            Container(
              height: screenWidth/20,
              decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: Offset(2, 2),
                  ),
                ],
                borderRadius: BorderRadius.all(Radius.circular(15)),
              ),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 10,right: 10,top: 10),
                    child: Column(
                      children: <Widget>[
                        Progresso(
                            progressColor: primary,
                            backgroundColor: Colors.grey,
                            progressStrokeWidth: screenWidth/20,
                            backgroundStrokeWidth: screenWidth/20,
                            progress: User.length/180,
                            progressStrokeCap: StrokeCap.round,
                            backgroundStrokeCap: StrokeCap.round),
                      ],
                    ),
                  ),
            ),
            Stack(
                  children: [
                    Container(
                      alignment: Alignment.centerLeft,
                      margin: const EdgeInsets.only(top: 16),
                      child: Text(
                        "${User.length}/180 Days",
                        style: TextStyle(
                          fontFamily: "BebasNeue-Bold",
                          fontSize: screenWidth / 24,
                        ),
                      ),
                    ),
                    Container(
                      alignment: Alignment.centerRight,
                      margin: const EdgeInsets.only(top: 16),
                      child: Text(
                        "${((User.length/180)*100).toStringAsFixed(2)}%",
                        style: TextStyle(
                          fontFamily: "BebasNeue-Bold",
                          fontSize: screenWidth / 24,
                        ),
                      ),
                    ),
                  ],
            ),

            Stack(
              children: [
                Container(
                  alignment: Alignment.centerLeft,
                  margin: const EdgeInsets.only(top: 16,bottom: 16),
                  child: Text(
                    _month,
                    style: TextStyle(
                      fontFamily: "BebasNeue-Bold",
                      fontSize: screenWidth / 18,
                    ),
                  ),
                ),
                Container(
                  alignment: Alignment.centerRight,
                  margin: const EdgeInsets.only(top: 16,bottom: 16),
                  child: GestureDetector(
                    onTap: ()async{
                      final month = await showMonthPicker(context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(DateTime.now().year),
                          lastDate: DateTime(DateTime.now().year+1,0),
                      );
                      if(month != null){
                        setState((){
                          _month = DateFormat('MMMM').format(month);
                        });
                      }
                    },
                    child: Text(
                      "Pick a Month" ,
                      style: TextStyle(
                        fontFamily: "BebasNeue-Bold",
                        fontSize: screenWidth / 18,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SingleChildScrollView(
              child: SizedBox(
                height: screenHeight/1.65,
                child: StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection("student")
                      .doc(User.id)
                      .collection("Record")
                      .snapshots(),
                  builder: (BuildContext context,AsyncSnapshot<QuerySnapshot> snapshot){
                    if(snapshot.hasData){
                      final snap= snapshot.data!.docs;
                      User.length = snap.length;
                      return ListView.builder(
                        itemCount: snap.length,
                        itemBuilder: (context,index){
                          return DateFormat('MMMM').format(snap[index]['date'].toDate()) == _month ? Card(
                            margin: const EdgeInsets.only(top: 0, left: 4,right: 4,bottom: 12),
                            elevation: 0.0,
                            color: const Color(0x00000000),
                            child: FlipCard(
                              direction: FlipDirection.HORIZONTAL,
                              speed: 1000,
                              onFlipDone: (status) {
                                if (kDebugMode) {
                                  print(status);
                                }
                              },
                              front: Container(
                                height: screenWidth/5,
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black26,
                                      blurRadius: 10,
                                      offset: Offset(2, 2),
                                    ),
                                  ],
                                  borderRadius: BorderRadius.all(Radius.circular(15)),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(child: Container(
                                      decoration: BoxDecoration(
                                        color:  primary,
                                        borderRadius: const BorderRadius.all(Radius.circular(15)),
                                      ),
                                      child: Center(
                                        child: Text(
                                          DateFormat('EE\ndd').format(snap[index]['date'].toDate()),
                                          style: TextStyle(
                                            fontFamily: "BebasNeue-Bold",
                                            fontSize: screenWidth / 25,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                    ),
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            "Check In",
                                            style: TextStyle(
                                              fontFamily: "BebasNeue-Regular",
                                              fontSize: screenWidth / 25,
                                              color: Colors.black54,
                                            ),
                                          ),
                                          Text(
                                            snap[index]['checkIn'],
                                            style: TextStyle(
                                              fontFamily: "BebasNeue-Bold",
                                              fontSize: screenWidth / 25,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            "Check Out",
                                            style: TextStyle(
                                              fontFamily: "BebasNeue-Regular",
                                              fontSize: screenWidth / 25,
                                              color: Colors.black54,
                                            ),
                                          ),
                                          Text(
                                            snap[index]['checkOut'],
                                            style: TextStyle(
                                              fontFamily: "BebasNeue-Bold",
                                              fontSize: screenWidth / 25,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              back: Container(
                                height: screenWidth/5,
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black26,
                                      blurRadius: 10,
                                      offset: Offset(2, 2),
                                    ),
                                  ],
                                  borderRadius: BorderRadius.all(Radius.circular(15)),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(child: Container(
                                      decoration: BoxDecoration(
                                        color:  primary,
                                        borderRadius: const BorderRadius.all(Radius.circular(15)),
                                      ),
                                      child: Center(
                                        child: Text(
                                          snap[index]['att'],
                                          style: TextStyle(
                                            fontFamily: "BebasNeue-Bold",
                                            fontSize: screenWidth / 20,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                    ),
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            "Time",
                                            style: TextStyle(
                                              fontFamily: "BebasNeue-Regular",
                                              fontSize: screenWidth / 20,
                                              color: Colors.black54,
                                            ),
                                          ),
                                          Text(
                                            snap[index]['hr']+" hr "+snap[index]['min']+" min "+snap[index]['sec']+" sec",
                                            style: TextStyle(
                                              fontFamily: "BebasNeue-Bold",
                                              fontSize: screenWidth / 25,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ) : const SizedBox();
                        },
                      );
                    } else {
                      return const SizedBox();
                    }
                  },
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
