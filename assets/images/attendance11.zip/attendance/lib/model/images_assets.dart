class ImagesAsset {
  static String pin = 'assets/images/pin.png';
}